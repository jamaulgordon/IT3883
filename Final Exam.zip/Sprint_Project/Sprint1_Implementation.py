# Program Name: Sprint_Implementation.py
# Course: IT3883/W02
# Student Name: Jamaul Gordon
# Assignment Number: Final Exam
# Due Date: 05/04/25


# Coin conversion program: Converts pseudo-English coin statements into dollar amounts

coin_values = {
    "penny": 0.01,
    "nickel": 0.05,
    "dime": 0.10,
    "quarter": 0.25
}

def normalize_coin(coin):
    # Handles plural forms
    if coin.endswith("ies"):
        return coin[:-3] + "y"  # pennies -> penny
    elif coin.endswith("s"):
        return coin[:-1]
    return coin

def parse_sentence(sentence):
    total = 0.0
    sentence = sentence.replace(" and ", ", ")
    parts = sentence.split(", ")
    for part in parts:
        tokens = part.strip().split()
        if len(tokens) >= 2:
            quantity = int(tokens[0])
            coin = normalize_coin(tokens[1])
            if coin in coin_values:
                total += quantity * coin_values[coin]
    return round(total, 2)

# Example usage
if __name__ == "__main__":
    test = input("Enter coin sentence: ")
    print(parse_sentence(test))
